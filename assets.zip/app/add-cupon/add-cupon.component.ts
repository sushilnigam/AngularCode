import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CuponModel } from '../models/cupon-model';
import { CuponServiceService } from '../Services/cupon-service.service';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-add-cupon',
  templateUrl: './add-cupon.component.html',
  styleUrls: ['./add-cupon.component.css']
})
export class AddCuponComponent implements OnInit {
  
  

  error: any;
  cupon: any ={
    cuponId: 0,
    id: '',
    isPercentage: false,
    Amount: 0,
    ExpiryDate: new Date(),
  };
  
  constructor(private cuponService: CuponServiceService) {}

  ngOnInit(): void {
    
  }

 
 


  onCreateCupon(cupon: CuponModel) {
    console.log(cupon);
    // Send Http request
    cupon.cuponId=Math.floor((Math.random() * 100000) + 1);
    this.cuponService.addCupon(cupon);
    //this.onReadCupons();
  }

}