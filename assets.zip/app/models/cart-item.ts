import { Product } from "./product.model";

export interface CartItem {
    productId: number;
id?: string;
    Quantity: number;
    name: string;
    size: string;
    color: string;
    imageUrls: string;
    price: number;
Discount?:number;
}
