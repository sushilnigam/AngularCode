export class Size {
}
