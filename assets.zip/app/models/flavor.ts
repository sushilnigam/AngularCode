export interface Flavor {
    name: string;
    color: string;
}