export interface CuponModel {
   
   CuponName?:string;
    cuponId: number;
    id?:string;
    isPercentage?:boolean;
    Amount:number;
    ExpiryDate:Date;
}
