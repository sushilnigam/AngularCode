import { Flavor } from "./flavor";
import { Size } from "./size";

export interface Product {
    id?: string;
    Productid: number;
    name: string;
    size:string;
    color:string;
    imageUrls: string;
    price: number;
    Quantity:number;
    Discount?:number;
    Ratings?:number;
    //flavors: Flavor[];
    //sizes: Size[];
}