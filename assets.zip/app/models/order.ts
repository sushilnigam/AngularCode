import { CartItem } from "./cart-item";

export interface Order {
    id?: string;
    OrderId?: string;
    cartItem: CartItem[];
    Total?:string;
	VoucherDiscount?:string;
    CartDiscount?:string;
    Shipping?:string;
    GrandTotal?:string;
    VoucherID?:string;
}

