﻿export class User {
    id?:string;
    userName: string | undefined;
    password: string | undefined;
    phone: string | undefined;
    email: string | undefined;
    firstName?: string ;
    lastName?: string ;
    token?: string ;
}