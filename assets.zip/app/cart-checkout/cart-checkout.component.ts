import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Cart } from '../models/cart';
import { CartItem } from '../models/cart-item';
import { CartService } from '../Services/cart.service';
import { CuponModel } from '../models/cupon-model';
import { CuponServiceService } from '../Services/cupon-service.service';
import { ProductService } from '../Services/product.service';
import { OrderService } from '../Services/order.service';
import { Order } from '../models/order';

@Component({
  selector: 'app-cart-checkout',
  templateUrl: './cart-checkout.component.html',
  styleUrls: ['./cart-checkout.component.css']
})
export class CartCheckoutComponent implements OnInit {

  CartItem: CartItem [] = [];
  _CartItem!: any; 
  order:any={};
  cart: Cart = new Cart;
  cartDetails: any;
  error: any;
  isFetching: boolean=true;
  selectedOption:boolean=false;
  voucherId:number | undefined;
  total:number=0;
  discount:number=0;
  grandtotal:number=0;
  shipping:number=50;
  cartdiscount:number=0;
  //constructor(private cartService: CartService,private productService:ProductService) {}
  constructor(private cuponService:CuponServiceService,
    private cartService: CartService,private _activatedRoute: ActivatedRoute,
    private http: HttpClient, private productService: ProductService,
    private route: Router,private orderService:OrderService) {}

  _getCart(): void {
    this.cartService.getCartItems().subscribe((data: any) => {
      //this.cart = data.data;
      this.CartItem = data;
      // this.cartDetails = data.data;
      console.log(this.CartItem);
      this.getCartTotal();
    });
  }

  _increamentQTY(id: any, quantity: number): void {
    const payload = {
      productId: id,
      quantity,
    };
   
  }
  _emptyCart(): void {
    this.cartService.emptyCart().subscribe(() => {
     // this._getCart();
   
      alert('Cart Emptied');
    });
  }
  ngOnInit(): void {
   this._getCart();
  
  }

  decreaseQuantity(productId:number)
  {
    this._CartItem=this.CartItem.find(p=> p.productId==productId);
    this._CartItem.Quantity=this._CartItem.Quantity-1;
    this.cartService.increaseQty(this._CartItem).subscribe((data: any) => {
      console.log(this._CartItem);
    });
  }

  increaseQuantity(productId:number)
  {
    this._CartItem=this.CartItem.find(p=> p.productId==productId);
    this._CartItem.Quantity=this._CartItem.Quantity+1;
    this.cartService.increaseQty(this._CartItem).subscribe((data: any) => {
    console.log(this._CartItem);
    });
  }

getCartTotal()
{
  console.log('getCartTotal');
  this.CartItem.forEach(c=>{
    this.total=this.total+(c.Quantity*c.price);
    this.cartdiscount=this.cartdiscount+c.Discount!;
    this.grandtotal=this.total+this.shipping-this.cartdiscount;
    console.log(c.Quantity*c.price);
  });
}
  showProductDetails(productId:number)
  {
    const queryParams: Params = { productid: productId };

  this.route.navigate(
    ['/productDeatils'], 
    {
      relativeTo: this._activatedRoute,
      queryParams: queryParams, 
      queryParamsHandling: 'merge', // remove to replace all query params by provided
    });
    console.log(productId);
    //this.route.navigate('/productDeatils/${productId}');
  }

  toggleVoucher(evt: any)
  {
//console.log(evt);
this.selectedOption = evt.target.checked;
//console.log(evt.target.checked);
  }
  applyVoucher()
  {
    console.log(this.voucherId);
    this.cuponService.fetchCuponsDetails(this.voucherId).subscribe((data: CuponModel) => {
      //this.getCartTotal();
      this.total=  this.total-data.Amount;
      this.grandtotal=this.total+this.shipping-this.cartdiscount;
      this.discount=data.Amount;
      console.log(data);
    });
  }

  DeleteCartItem(productId:any)
  {
    console.log(productId);
    this.cartService.deleteCartItems(productId).subscribe((data: any) => {
      //this.getCartTotal();
      // this.total=  this.total-data.Amount;
      // this.grandtotal=this.total+this.shipping-this.cartdiscount;
      // this.discount=data.Amount;
      console.log(data);
      this._getCart();
    });
//deleteCartItems
  }
  addOrder()
  {
    console.log( JSON.stringify(this.order));
    this._getCart();
    console.log(this.CartItem);
    this.order.cartItem=this.CartItem;
   this.order.OrderId=Math.floor((Math.random() * 100000) + 1);
   //console.log( JSON.stringify(this.order));
   this.order.Total =this.total;
   this.order.CartDiscount =this.cartdiscount;
   this.order.GrandTotal =this.grandtotal;
   this.order.Shipping =this.shipping;
   this.order.VoucherID =this.voucherId;
   this.order.VoucherDiscount =this.discount;
   this.orderService.createAndStoreOrder(this.order);
   this.route.navigateByUrl("/orderlist");
  }

}
