import { Flavor } from './flavor';

describe('Flavor', () => {
  it('should create an instance', () => {
    expect(new Flavor()).toBeTruthy();
  });
});
