import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../models/product.model';
import { ProductService } from '../Services/product.service';
import { FormGroup, FormControl, Validators} from '@angular/forms';
//import 'rxjs/add/operator/filter';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {
  loadedProducts: Product[] = [];
  imageUrl='../assets/images/i1.jpg';
  product = {} as Product;
  error: any;
  productid: number=0;

  constructor(private _activatedRoute: ActivatedRoute, private productService: ProductService) {}
  ngOnInit(): void {
    this._activatedRoute.queryParams
    .subscribe((params: any) => {
      this.productid=params["productid"];
      this.onGetProductById(this.productid);
    }
      ); 
      this.onFetchProducts();
  }

  onGetProductById(productid:number)
  {
     //this.onFetchProducts();
     this.productService.fetchProductsbyId(this.productid).subscribe(
      product => {
        //this.isFetching = false;
        this.product = product;
        //console.log(product);
      },
      error => {
        this.error = error.message;
       // console.log(error);
      }
    );
  }

  onCreateProduct(productData: Product) {
    console.log(productData);
    this.productService.updateProduct(productData).subscribe(
      product => {
        //this.isFetching = false;
       
        console.log(product);
      },
      error => {
        this.error = error.message;
       console.log(error);
      }
    );;
   // const index: number = this.loadedProducts.findIndex( p=> p.Productid==this.productid);

   // console.log(index);
   // if (index !== -1) {
     
      //productData.Productid=this.productid;
      //productData.Quantity=10;
      //console.log(productData);
      //this.loadedProducts[index]=productData;
        //this.loadedProducts.splice(index, 1);
   // }  

    //console.log(index);

   // console.log( this.loadedProducts);
    
    //this.productService.deletePosts();

    //this.productService.createAndStoreProductt(productData);
    //this.productService.bulkInsertProduct(this.loadedProducts);

  }

  onChange(e:any){
    //console.log('event');
    this.imageUrl=e;
    //console.log(e);
  }

  onFetchProducts() {
    // Send Http request
    //this.isFetching = true;
    this.productService.fetchProducts().subscribe(
      product => {
        this.loadedProducts = product;
        //console.log(product);
      },
      error => {
        this.error = error.message;
      }
    );
  } 
  
}
