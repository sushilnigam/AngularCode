import { TestBed } from '@angular/core/testing';

import { CuponServiceService } from './cupon-service.service';

describe('CuponServiceService', () => {
  let service: CuponServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CuponServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
