import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCuponComponent } from './add-cupon/add-cupon.component';
import { AuthComponent } from './auth/auth.component';
import { CartCheckoutComponent } from './cart-checkout/cart-checkout.component';
import { CartComponent } from './cart/cart.component';
import { CreateproductComponent } from './createproduct/createproduct.component';
import { DataGridComponent } from './data-grid/data-grid.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { HomepageComponent } from './homepage/homepage.component';
import { OrderListComponent } from './order-list/order-list.component';
import { OrderComponent } from './order/order.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductpageComponent } from './productpage/productpage.component';
import { RegisterComponent } from './register';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { VoucherDetailsComponent } from './voucher-details/voucher-details.component';
import { VoucherListComponent } from './voucher-list/voucher-list.component';

const routes: Routes = [
  
  {path: "showGrid", component: DataGridComponent},
  {path: "addCupon", component: AddCuponComponent},
  {path: "addProduct", component: CreateproductComponent},
  {path: "EditProduct", component: EditProductComponent},
  {path: "product/:id", component: ProductpageComponent},
  {path: "ProductList", component: ProductpageComponent},
  {path: "cart", component: CartComponent},
  {path: "logout", component: AuthComponent},
  {path: "checkout", component: CartCheckoutComponent},
  {path: "", component: AuthComponent},
  {path: "vouchers", component: VoucherListComponent},
  {path: "productDeatils", component: ProductDetailsComponent},
  {path: "addorder", component: OrderComponent},
  {path: "orderlist", component: OrderListComponent},
  {path:"voucherdetails",component:VoucherDetailsComponent},
  {path:"userprofile",component:UserProfileComponent},
  {path:"register",component:RegisterComponent},
  {
    path: "auth",
    loadChildren: () => import("./auth/auth.module").then(m => m.AuthModule)
  }
  
  //{path: "**", component: ProductpageComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
