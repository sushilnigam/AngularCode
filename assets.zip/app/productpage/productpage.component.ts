import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { Product } from '../models/product.model';
import { ProductService } from '../Services/product.service';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CartItem } from '../models/cart-item';
import { Cart } from '../models/cart';
import { CartService } from '../Services/cart.service';
import { CssClassApplier } from 'ag-grid-community';
import { PostsService } from '../Services/posts.service';

@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})

export class ProductpageComponent implements OnInit {
  cc:CartItem={
    productId: 0,
    Quantity: 0,
    name: '',
    size: '',
    color: '',
    imageUrls: '',
    price: 0
  };
  loadedProducts: Product[] = [];
  searchText:string='';
  isFetching = false;
  product:any;
  error = '';
  imageUrl='../assets/images/i1.jpg';
  cartItems: CartItem[]=[];
  cart: Cart = new Cart;
 cartDetails: any;
  private errorSub: Subscription = new Subscription;

  constructor(private cartService: CartService,private _activatedRoute: ActivatedRoute,private http: HttpClient, private productService: ProductService,private route: Router,private postsService: PostsService) {}

  ngOnInit() {
    this.onFetchProducts();
  }
  showProductDetails(productId:number)
  {
    const queryParams: Params = { productid: productId };

  this.route.navigate(
    ['/productDeatils'], 
    {
      relativeTo: this._activatedRoute,
      queryParams: queryParams, 
      queryParamsHandling: 'merge', // remove to replace all query params by provided
    });
    console.log(productId);
    //this.route.navigate('/productDeatils/${productId}');
  }

  onDeleteProductr(productid:any)
  {
     this.productService.deletePosts(productid).subscribe( product => {
      //this.isFetching = false;
      //console.log(product);
      this.onFetchProducts();
    },
    error => {
      this.error = error.message;
     // console.log(error);
    });
   
  }

  onCreateProduct(productData: Product) {
    console.log(productData);
    // Send Http request
    productData.Productid=Math.floor((Math.random() * 100000) + 1);
    this.productService.createAndStoreProductt(productData);
    this.onFetchProducts();
  }
  onChange(e:any){
    console.log('event');
    this.imageUrl=e;
    console.log(e);
  }
  AddToCart(productid:number)
  {
     this.product=this.loadedProducts.find(p=> p.Productid ===productid);
      this.cc.productId=productid;
      this.cc.Quantity=1;
      this.cc.price=this.product.price;
      this.cc.name=this.product.name;
      this.cc.size=this.product.size;
      this.cc.color=this.product.color;
      this.cc.imageUrls=this.product.imageUrls;
      this.cartService.addToCart(this.cc);
      console.log(this.product);
  }
  onFetchProducts() {
    this.searchText='';
    // Send Http request
    this.isFetching = true;
    this.productService.fetchProducts().subscribe(
      product => {
        //this.isFetching = false;
        this.loadedProducts = product;
        //console.log(product);
      },
      error => {
        this.error = error.message;
       // console.log(error);
      }
    );
  }
  onActivate() {
    this.postsService.activatedEmitter.next(true);
  }
  filterProduct(event: any){
    //console.log(event.target.value);
       // Send Http request
    this.isFetching = true;
    this.productService.searchProducts(event.target.value).subscribe(
      product => {
        this.loadedProducts = product;
        console.log(product);
      },
      error => {
        this.error = error.message;
       // console.log(error);
      }
    );
  }
  sortProductList(param:any)
  {
    if(param =='name')
    this.loadedProducts =this.loadedProducts.sort((a, b) => (a.name > b.name ? 1 : -1));
    else if (param =='Size')
    this.loadedProducts =this.loadedProducts.sort((a, b) => (a.size > b.size ? 1 : -1));
    else if (param =='Color')
    this.loadedProducts =this.loadedProducts.sort((a, b) => (a.color > b.color ? 1 : -1));
    else if (param =='Price')
    this.loadedProducts =this.loadedProducts.sort((a, b) => (a.price > b.price ? 1 : -1));
    else if (param =='Discount')
    this.loadedProducts =this.loadedProducts.sort((a, b) => (a.Discount! > b.Discount! ? 1 : -1));
  }
}
