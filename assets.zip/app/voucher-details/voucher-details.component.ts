import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CuponModel } from '../models/cupon-model';
import { CuponServiceService } from '../Services/cupon-service.service';

@Component({
  selector: 'app-voucher-details',
  templateUrl: './voucher-details.component.html',
  styleUrls: ['./voucher-details.component.css']
})
export class VoucherDetailsComponent implements OnInit {
  error: any;
  voucher = {} as CuponModel;
  pageTitle:string ='Product Details';
voucherid:number=67190;
  constructor(private http: HttpClient, private cuponService: CuponServiceService,private route: ActivatedRoute) {
    console.log('Called Constructor');
    this.route.queryParams.subscribe((params: { [x: string]: number; }) => {
          this.voucherid = params['voucherid'];
    });
   }

  ngOnInit(): void {
    this.cuponService.fetchCuponsDetails(this.voucherid).subscribe(
      cupon => {
        //this.isFetching = false;
        this.voucher = cupon;
        console.log(cupon);
      },
      error => {
        this.error = error.message;
       // console.log(error);
      }
    );
  }

}
