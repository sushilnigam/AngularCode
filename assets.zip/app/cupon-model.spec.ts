import { CuponModel } from './cupon-model';

describe('CuponModel', () => {
  it('should create an instance', () => {
    expect(new CuponModel()).toBeTruthy();
  });
});
