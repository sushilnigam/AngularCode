import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {
  CellClassParams,
  
    CellClassRules,
  ColDef,
  GridReadyEvent,
  ICellRendererParams,
  ValueParserParams,
} from 'ag-grid-community';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

@Component({
  selector: 'app-data-grid',
  templateUrl: './data-grid.component.html',
  styleUrls: ['./data-grid.component.css']
})

export class DataGridComponent implements OnInit {
  
  public columnDefs: ColDef[] = [
    { field: 'athlete' },
    {
      field: 'age',
      maxWidth: 90,
      //valueParser: this.numberParser,
      cellClassRules: {
        'rag-green': 'x < 20',
        'rag-amber': 'x >= 20 && x < 25',
        'rag-red': 'x >= 25',
      },
    },
   
    {
      field: 'year',
      maxWidth: 90,
     
     
      cellRenderer: this.ragRenderer,
    },
   
    {
      field: 'sport',
      cellClass: this.cellClass,
    },
    {
      field: 'gold',
     
      cellStyle: {
        // you can use either came case or dashes, the grid converts to whats needed
        backgroundColor: '#aaffaa', // light green
      },
    },
   
    
  ];
  
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 150,
    editable: true,
  };
  public rowData!: any[];

  constructor(private http: HttpClient) {}
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  onGridReady(params: GridReadyEvent) {
    this.http
      .get<any[]>('https://www.ag-grid.com/example-assets/olympic-winners.json')
      .subscribe((data) => (this.rowData = data));
  }


 ragCellClassRules: CellClassRules = {
  'rag-green-outer': (params: { value: number; }) => params.value === 2008,
  'rag-amber-outer': (params: { value: number; }) => params.value === 2004,
  'rag-red-outer': (params: { value: number; }) => params.value === 2000,
};
 
cellStyle(params: CellClassParams) {
  const color ='red';
  return {
    backgroundColor: color,
  };
}
 cellClass(params: CellClassParams) {
  return params.value === 'Swimming' ? 'rag-green' : 'rag-amber';
}
 
 ragRenderer(params: ICellRendererParams) {
  return '<span class="rag-element">' + params.value + '</span>';
}
 




}




