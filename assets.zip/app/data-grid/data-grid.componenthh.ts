import { Component, OnInit } from '@angular/core';
import {
  CellClassParams,
  CellClassRules,
  ColDef,
  GridReadyEvent,
  ICellRendererParams,
  ValueParserParams,
} from 'ag-grid-community';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

@Component({
  selector: 'app-data-grid',
  templateUrl: './data-grid.component.html',
  styleUrls: ['./data-grid.component.css']
})
export class DataGridComponent implements OnInit {
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 150,
    editable: true,
  };

  constructor() { }

  ngOnInit(): void {
  }
  //columnDefs = [{ field: "make",cellStyle: {color: 'red', 'background-color': 'green'} }, { field: "model" }, { field: "price" }];

  public columnDefs: ColDef[] = [
   
    {
      field: 'price',
      maxWidth: 90,
      valueParser: this.numberParser,
      cellClassRules: {
        'rag-green': 'x < 20',
        'rag-amber': 'x >= 20 && x < 25',
        'rag-red': 'x >= 25',
      },
    },
      {
      field: 'make',
      maxWidth: 90,
      valueParser: this.numberParser,
      //cellClassRules: this.ragCellClassRules,
      cellRenderer: this.ragRenderer,
    },

    {
      field: 'model',
      cellClass: this.cellClass,
    },
   
   
   
  ];
  rowData = [
    { make: "Toyota", model: "Celica", price: 35000 },
    { make: "Ford", model: "Mondeo", price: 32000 },
    { make: "Porsche", model: "Boxter", price: 72000 }
  ];

   ragCellClassRules: CellClassRules = {
    'rag-green-outer': (params) => params.value === 2008,
    'rag-amber-outer': (params) => params.value === 2004,
    'rag-red-outer': (params) => params.value === 2000,
  };

   cellStyle(params: CellClassParams) {
    const color = this.numberToColor(params.value);
    return {
      backgroundColor: color,
    };
  }
   cellClass(params: CellClassParams) {
    return params.value === 'Swimming' ? 'rag-green' : 'rag-amber';
  }
   numberToColor(val: number) {
    if (val === 0) {
      return '#ffaaaa';
    } else if (val == 1) {
      return '#aaaaff';
    } else {
      return '#aaffaa';
    }
  }
   ragRenderer(params: ICellRendererParams) {
    return '<span class="rag-element">' + params.value + '</span>';
  }
   numberParser(params: ValueParserParams) {
    const newValue = params.newValue;
    let valueAsNumber;
    if (newValue === null || newValue === undefined || newValue === '') {
      valueAsNumber = null;
    } else {
      valueAsNumber = parseFloat(params.newValue);
    }
    return valueAsNumber;
  }
}
