import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../models/product.model';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  error: any;
  product = {} as Product;
  pageTitle:string ='Product Details';
productid:number=28734;
  constructor(private http: HttpClient, private productService: ProductService,private route: ActivatedRoute) 
  {
    console.log('Called Constructor');
    this.route.queryParams.subscribe((params: { [x: string]: number; }) => {
          this.productid = params['productid'];
    });
  }

  ngOnInit(): void {
    //this.onFetchProducts();
    this.productService.fetchProductsbyId(this.productid).subscribe(
      product => {
        //this.isFetching = false;
        this.product = product;
        console.log(product);
      },
      error => {
        this.error = error.message;
       // console.log(error);
      }
    );
  }

}
