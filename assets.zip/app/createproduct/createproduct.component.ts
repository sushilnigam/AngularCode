import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../models/product.model';
import { ProductService } from '../Services/product.service';
import { FormGroup, FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-createproduct',
  templateUrl: './createproduct.component.html',
  styleUrls: ['./createproduct.component.css']
})
export class CreateproductComponent implements OnInit {
  imageUrl='../assets/images/i1.jpg';

  constructor(private _activatedRoute: ActivatedRoute,private http: HttpClient, private productService: ProductService,private route: Router) {}
  ngOnInit(): void {
  }

  onCreateProduct(productData: Product) {
    console.log(productData);
    // Send Http request
    productData.Quantity=200;
   productData.Productid=Math.floor((Math.random() * 100000) + 1);
    this.productService.createAndStoreProductt(productData);
    //this.onFetchProducts();
  }
  onChange(e:any){
    console.log('event');
    this.imageUrl=e;
    console.log(e);
  }
}
