import { Size } from './size';

describe('Size', () => {
  it('should create an instance', () => {
    expect(new Size()).toBeTruthy();
  });
});
