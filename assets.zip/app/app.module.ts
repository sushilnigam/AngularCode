import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { comp1 } from './comp1';
import { comp2 } from './comp2';

import { AgGridModule } from 'ag-grid-angular';
import { ProductpageComponent } from './productpage/productpage.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { CreateproductComponent } from './createproduct/createproduct.component';
import { CartComponent } from './cart/cart.component';
import { AddCuponComponent } from './add-cupon/add-cupon.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { DataGridComponent } from './data-grid/data-grid.component';
import { SharedModule } from './shared/shared.module';
import { CoreModule } from './core.module';
import { LoggingService } from './Services/logging.service';
import { CartCheckoutComponent } from './cart-checkout/cart-checkout.component';
import { VoucherListComponent } from './voucher-list/voucher-list.component';
import { OrderListComponent } from './order-list/order-list.component';
import { OrderComponent } from './order/order.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { VoucherDetailsComponent } from './voucher-details/voucher-details.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { RegisterComponent } from './register';

@NgModule({
  declarations: [
    AppComponent,
    comp1,
    comp2,
    DataGridComponent,
    ProductpageComponent,
    ProductDetailsComponent,
    CreateproductComponent,
    CartComponent,
    AddCuponComponent,
    EditProductComponent,
    CartCheckoutComponent,
    VoucherListComponent,
    OrderComponent,
OrderListComponent,
VoucherDetailsComponent,
UserProfileComponent,
RegisterComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    SharedModule,
    CoreModule,
    AgGridModule.withComponents([]),
    NgbModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { 

}
