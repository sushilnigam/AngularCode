import { Order } from '../models/order';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { Subject, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  error = new Subject<string>();

  constructor(private http: HttpClient) { }

  createAndStoreOrder(orderData: Order) {
    console.log( JSON.stringify(orderData));
    //const productData: Product = { name: title, price: price, id:id,size:'large',color:'Red',imageUrls:''};
    this.http.post<{name: string }>(
        'https://mytestapp-45659.firebaseio.com/order.json',
        JSON.stringify(orderData)
      )
      .subscribe(
        responseData => {
          console.log(responseData);
        },
        error => {
          console.log(error.message);
          this.error.next(error.message);
        }
      );
  }
  fetchOrders() {
    return this.http
      .get<{ [key: string]: Order }>(
        'https://mytestapp-45659.firebaseio.com/order.json'
      
      )
      .pipe(
        map(responseData => {
          const postsArray: Order[] = [];
          for (const key in responseData) {
            if (responseData.hasOwnProperty(key)) {
              postsArray.push({ ...responseData[key], id:key});
            }
            //console.log(responseData);
            //console.log(responseData[key].name);
          }
          return postsArray;
        }),
        catchError(errorRes => {
          // Send to analytics server
          return throwError(errorRes);
        })
      );
  }
}
