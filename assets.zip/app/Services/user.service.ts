﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { User } from '../models/user';

@Injectable({ providedIn: 'root' })
export class UserService {
    constructor(private http: HttpClient) { }

    getAll() {
        //return this.http.get<User[]>(`${config.apiUrl}/users`);
    }

    register(user: User) {
        console.log(user);
       return this.http.post<{ name: string }>('https://mytestapp-45659.firebaseio.com/user.json',JSON.stringify(user));
    }

    delete(id: number) {
        //return this.http.delete(`${config.apiUrl}/users/${id}`);
    }
}