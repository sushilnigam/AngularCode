import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Cart } from '../models/cart';
import { CartItem } from '../models/cart-item';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  error: any;

  constructor(private http: HttpClient) {}
  getAllProducts() {
    return this.http.get('${environment.baseURL}/product');
  }

  addToCart(cart: CartItem) {
    
      this.http
        .post<{ name: string }>(
          'https://mytestapp-45659.firebaseio.com/CartItem.json',
          JSON.stringify(cart)
        )
        .subscribe(
          responseData => {
            console.log(responseData);
          },
          error => {
            this.error.next(error.message);
          }
        );
    
    return 1;
  }

  getCartItems() {
    return this.http
    .get<{ [key: string]: CartItem }>(
      'https://mytestapp-45659.firebaseio.com/CartItem.json'
    )
    .pipe(
      map(responseData => {
        const postsArray: CartItem[] = [];
        //let modal = {} as CartItem;
        for (const key in responseData) {
         
          if (responseData.hasOwnProperty(key)) {
            postsArray.push({ ...responseData[key], id: key });
            //modal=responseData[key];
          
          }
        }
        return postsArray;
      }),
      catchError((errorRes: any) => {
        // Send to analytics server
        return throwError(errorRes);
      })
    );
  }

  fetchCartItembyId(productid:number) {
   
    return this.http
    .get<{ [key: string]: CartItem }>(
      'https://mytestapp-45659.firebaseio.com/product.json'
    )
      .pipe(
        map(responseData => {
          const postsArray: CartItem[] = [];
          let modal = {} as CartItem;
          for (const key in responseData) {
          
            if (responseData.hasOwnProperty(key)) {
              if(productid==responseData[key].productId)
              {
                //CartItem.push({ ...responseData[key], id:key});
                modal=responseData[key];
              }
             
            }
          }
         
          return modal;
        }),
        catchError(errorRes => {
          return throwError(errorRes);
        })
      );
  }

  increaseQty(cartItem: CartItem) {
    console.log(cartItem);
    return this.http.patch<{id:any}>('https://mytestapp-45659.firebaseio.com/CartItem/'+cartItem.id+'.json',   JSON.stringify({Quantity:cartItem.Quantity})) .pipe(
      map(responseData => {
        let modal = {} as CartItem;
        return modal;
      }),
      catchError(errorRes => {
        return throwError(errorRes);
      }));
  }
  emptyCart() {
    return this.http.delete('${environment.baseURL}/cart/empty-cart');
  }

  deleteCartItems(productId:any) {
    console.log(productId);
    return this.http.delete<{id:any}>(
      'https://mytestapp-45659.firebaseio.com/CartItem/'+productId+'.json'
    ).pipe(map(responseData => 
      console.log(responseData)
     
      ),
    catchError(errorRes => {
      console.log(errorRes);
      return throwError(errorRes);
    }));
  }
}
