import { Injectable } from '@angular/core';
import { CuponModel } from '../models/cupon-model';
import { HttpClient } from '@angular/common/http';
import { catchError, map, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CuponServiceService {
  error: any;

  constructor(private http: HttpClient) { }
  addCupon(cupon: CuponModel) {
    
    this.http
      .post<{ name: string }>(
        'https://mytestapp-45659.firebaseio.com/cupon.json',
        JSON.stringify(cupon)
      )
      .subscribe(
        (        responseData: any) => {
          console.log(responseData);
        },
        (        error: { message: any; }) => {
          this.error.next(error.message);
        }
      );
  
  return 1;
}

fetchCupons() {
  return this.http
    .get<{ [key: string]: CuponModel }>(
      'https://mytestapp-45659.firebaseio.com/cupon.json'
    )
    .pipe(
      map(responseData => {
        const postsArray: CuponModel[] = [];
        for (const key in responseData) {
          if (responseData.hasOwnProperty(key)) {
            postsArray.push({ ...responseData[key], id:key});
          }
          //console.log(responseData);
          //console.log(responseData[key].name);
        }
        return postsArray;
      }),
      catchError(errorRes => {
        // Send to analytics server
        return throwError(errorRes);
      })
    );
}

fetchCuponsDetails(CuponID:any) {
  return this.http
    .get<{ [key: string]: CuponModel }>(
      'https://mytestapp-45659.firebaseio.com/cupon.json'
    )
    .pipe(
      map(responseData => {let postsArray: CuponModel={
          cuponId: 0,
          id:'',
          isPercentage:false,
          Amount:0,
          ExpiryDate:new Date
        };
        for (const key in responseData) {
          if(CuponID ==responseData[key].cuponId)
          {
          if (responseData.hasOwnProperty(key)) {
            postsArray=responseData[key];
          }
        }
        }
        return postsArray;
      }),
      catchError(errorRes => {
        // Send to analytics server
        return throwError(errorRes);
      })
    );
}
}
