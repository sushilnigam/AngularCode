import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { Subject, throwError } from 'rxjs';
import { Product } from '../models/product.model';

@Injectable({
  providedIn: 'root'
})

export class ProductService {
  error: any;
  constructor(private http: HttpClient) {}
  
  bulkInsertProduct(productData: Product[])
  {
     //const productData: Product = { name: title, price: price, id:id,size:'large',color:'Red',imageUrls:''};
     this.http
     .post<{ name: string }>(
       'https://mytestapp-45659.firebaseio.com/product.json',
       JSON.stringify(productData)
     )
     .subscribe(
       responseData => {
         console.log(responseData);
       },
       error => {
         this.error.next(error.message);
       }
     );
  }

  createAndStoreProductt(productData: Product) {
    //const productData: Product = { name: title, price: price, id:id,size:'large',color:'Red',imageUrls:''};
    this.http
      .post<{ name: string }>(
        //'https://mytestapp-45659.firebaseio.com/ecomdb/product.json',
        'https://mytestapp-45659.firebaseio.com/product.json',
        JSON.stringify(productData)
      )
      .subscribe(
        responseData => {
          console.log(responseData);
        },
        error => {
          this.error.next(error.message);
        }
      );
  }

  fetchProducts() {
    return this.http
      .get<{ [key: string]: Product }>(
        'https://mytestapp-45659.firebaseio.com/product.json'
      
      )
      .pipe(
        map(responseData => {
          const postsArray: Product[] = [];
          for (const key in responseData) {
            if (responseData.hasOwnProperty(key)) {
              postsArray.push({ ...responseData[key], id:key});
            }
            //console.log(responseData);
            //console.log(responseData[key].name);
          }
          return postsArray;
        }),
        catchError(errorRes => {
          // Send to analytics server
          return throwError(errorRes);
        })
      );
  }

  fetchProductsbyId(productid:number) {
    console.log(productid);
    return this.http
    .get<{ [key: string]: Product }>(
      //'https://mytestapp-45659.firebaseio.com/product.json'
      'https://mytestapp-45659.firebaseio.com/product.json?productid='+productid
    )
      .pipe(
        map(responseData => {
          const product: Product[] = [];
          let modal = {} as Product;
          for (const key in responseData) {
          
            if (responseData.hasOwnProperty(key)) {
              if(productid==responseData[key].Productid)
              {
                product.push({ ...responseData[key], id:key});
                modal=responseData[key];
                modal.id=key;
              }
             
            }
          }
         // console.log(product);
         console.log(modal);
          return modal;
        }),
        catchError(errorRes => {
          // Send to analytics server
          //console.log('function called');
          return throwError(errorRes);
        })
      );
  }

  deletePosts(productId:any) {
    console.log(productId);
    return this.http.delete<{id:any}>(
      'https://mytestapp-45659.firebaseio.com/product/'+productId+'.json'
    ).pipe(map(responseData => 
      console.log(responseData)
     
      ),
    catchError(errorRes => {
      console.log(errorRes);
      return throwError(errorRes);
    }));
  }

  updateProduct(productData:Product)
{
  let url=productData.id;
  let datas = JSON.stringify(productData);
  return this.http
  //.patch('https://mytestapp-45659.firebaseio.com/'+productData.id+'/product.json',datas).pipe
  .put<{id:any}>('https://mytestapp-45659.firebaseio.com/product/'+productData.id+'.json',datas).pipe
  (map(responseData => 
    console.log(responseData)
   
    ),
  catchError(errorRes => {
    return throwError(errorRes);
  }));

}

searchProducts(search:any) {
  return this.http
    .get<{ [key: string]: Product }>(
      'https://mytestapp-45659.firebaseio.com/product.json'
    
    )
    .pipe(
      map(responseData => {
        const postsArray: Product[] = [];
        for (const key in responseData) {
          if (responseData.hasOwnProperty(key)) {
            if(responseData[key].name.lastIndexOf(search)!=-1)
            {
            postsArray.push({ ...responseData[key], id:key});
            }
          }
          //console.log(responseData);
          //console.log(responseData[key].name);
        }
        return postsArray;
      }),
      catchError(errorRes => {
        // Send to analytics server
        return throwError(errorRes);
      })
    );
}
}
