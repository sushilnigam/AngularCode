import { Component, OnInit } from '@angular/core';
import { Order } from '../models/order';
import { OrderService } from '../Services/order.service';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css']
})
export class OrderListComponent implements OnInit {
  loadedOrders: Order[] = [];
  searchText:string='';
  isFetching = false;
  product:any;
  error = '';
  public gfg = false;
  constructor(private orderService:OrderService) { }

  ngOnInit(): void {
    this.onFetchOrders();
  }

  onFetchOrders() {
    this.searchText='';
    // Send Http request
    this.isFetching = true;
    this.orderService.fetchOrders().subscribe(
      orders => {
        //this.isFetching = false;
        this.loadedOrders = orders;
        console.log(orders);
      },
      error => {
        this.error = error.message;
      
      }
    );
  }
}
