import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CuponModel } from '../models/cupon-model';
import { CuponServiceService } from '../Services/cupon-service.service';
import { ProductService } from '../Services/product.service';

@Component({
  selector: 'app-voucher-list',
  templateUrl: './voucher-list.component.html',
  styleUrls: ['./voucher-list.component.css']
})
export class VoucherListComponent implements OnInit {

  loadedCupons: CuponModel[] = [];
  error: any;
  cupon: any ={
    cuponId: 0,
    id: '',
    isPercentage: false,
    Amount: 0,
    ExpiryDate: new Date(),
  };
  
  constructor(private cuponService: CuponServiceService) {}

  ngOnInit(): void {
    this.onReadCupons();
  }

  onReadCupons()
  {
    this.cuponService.fetchCupons().subscribe(
      cupon => {
        //this.isFetching = false;
        this.loadedCupons = cupon;
        //console.log(product);
      },
      error => {
        this.error = error.message;
       // console.log(error);
      }
    );
  }
 
 onDeleteVoucher(cuponId:number)
  {
    const index: number = this.loadedCupons.findIndex( p=> p.cuponId==cuponId);
    if (index !== -1) {
        this.loadedCupons.splice(index, 1);
    }    
  }

}
