// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  baseURL: 'http://localhost:4000',
  firebase:  {
    apiKey: 'AIzaSyCUP4LpdRFCtPRtqh2mtyF_ZcQ6H9Pqdiw',
    authDomain: "mytestapp-45659.firebaseapp.com",
    databaseURL: "https://mytestapp-45659.firebaseio.com",
    projectId: "mytestapp-45659",
    storageBucket: "mytestapp-45659.appspot.com",
    messagingSenderId: "724620313792",
    appId: "1:724620313792:web:c1991933790f6f1b9e9925"
  }
  
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
